#!/bin/bash
pdflatex -interaction=nonstopmode -output-directory=. main.tex
